
def Main(operation, a, b):

  if operation == 'add':
      return a + b

  elif operation == 'sub':
      return a - b

  elif operation == 'mul':
      return a * b

  elif operation == 'div':
      return a / b

  else:
      return -1
